import SwiftUI

struct ContentView: View {
    @State private var angle: Double = 0
    @State private var tapCount: Int = 0
    @State var hour: Int = 0
    @State var minuteSeg: Int = 0
    
    var isNight: Bool {

        let mod = tapCount % 24
        return mod < 12
    }
    
    var body: some View {
        let Sedat = isNight ? Color.yellow : Color.indigo.opacity(0.2)
        
        let Yalcin = isNight ? Text("AM") : Text("PM")
        
        ZStack {
            Sedat
                .ignoresSafeArea()
            
            Yalcin
                .offset(y:280)
                .font(.title)
                .bold()
            
            Text("Hour: \(hour)")
                .font(.title)
                .foregroundColor(.white)
                .offset(y: -280)
                .bold()
            
            Circle()
                .fill(Color.black)
                .frame(width: 300, height: 300)
            
            ZStack {
                Rectangle()
                    .fill(Color.white)
                    .frame(width: 8, height: 140)
                    .offset(y: -70)
                

            }
            .rotationEffect(.degrees(angle))
            
            Circle()
                .fill(Color.black)
                .frame(width: 12, height: 12)
        }
        .onTapGesture {
            angle += 15
            tapCount += 1
            hour += 1
            if hour == 24 { hour = 0 }
        }
        .animation(.bouncy(duration: 0.5, extraBounce: 0.5), value: angle)
    }
}
