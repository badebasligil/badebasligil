//Zeynep Bade Başlıgil - 4.9.25 - AP CSP - Clock
import SwiftUI


struct ContentView: View {
    @State private var angle: Double = 0
    @State private var angut: Double = 0
    @State private var tapCount: Int = 0
    @State var hour: Int = 0
    @State var AM: Int = 0
    @State var PM: Int = 0
    @State var minute: Int = 0
    
    
    var isNight: Bool {
        
        let mod = tapCount % 24
        return mod < 12
    }
    
    var body: some View {
        
        let Sedat = isNight ? Color.yellow : Color.indigo.opacity(0.8)
        
        let Yalcin = isNight ? Text("AM") : Text("PM")
        
        ZStack {
            Sedat
                .ignoresSafeArea()
            
            Yalcin
                .offset(y:280)
                .font(.title)
                .bold()
                .hidden()
            
            
            Text("Hour: \(hour)")
                .font(.title)
                .foregroundColor(.white)
                .offset(y: -280)
                .bold()
            
            Text("Minute: \(minute)")
                .font(.title)
                .foregroundColor(.white)
                .offset(y: -340)
                .bold()
            
            if Sedat == Color.yellow {
                Text("AM: \(AM)")
                    .font(.title)
                    .foregroundColor(.white)
                    .offset(y: -220)
                    .bold()
            } else {
                Text("PM: \(PM)")
                    .font(.title)
                    .foregroundColor(.white)
                    .offset(y: -220)
                    .bold()
            }
            
            
            
            
            Circle()
                .fill(Color.black)
                .frame(width: 300, height: 300)
            
            ZStack {
                Image(systemName: "figure.stand")
                    .resizable ()
                    .foregroundStyle(.purple)
                    .frame(width: 30, height: 120)
                    .offset(y: -60)
                    .rotationEffect(.degrees(angut))
                
                
                Image(systemName: "hand.raised.fill")
                    .resizable()
                    .foregroundStyle(.white)
                    .frame(width: 40, height: 60)
                    .offset(y: -30)
                    .rotationEffect(.degrees(angle))
                
            }

            
            
            
            
            Circle()
                .fill(Color.black)
                .frame(width: 12, height: 12)
            
            HStack {
                Button("- Hour") { 
                    hour = hour - 1
                    angle = angle - 15
                } 
                .offset(y:200)
                .foregroundStyle(.white)
                Button("+ Hour") { 
                    hour = hour + 1
                    angle = angle + 15
                }
                .offset(y:200)
                .foregroundStyle(.white)
            }
            HStack {
                Button("- Minute") { 
                    minute = minute - 1
                    angut = angut - 6
                } 
                .offset(y:250)
                .foregroundStyle(.white)
                Button("+ Minute") { 
                    minute = minute + 1
                    angut = angut + 6
                }
                .offset(y:250)
                .foregroundStyle(.white)
            }
        }
        .onTapGesture (count: 2) {
            angle += 15
            angut += 6
            tapCount += 1
            hour += 1
            if hour == 24 { hour = 0 }
            AM += 1
            if AM == 12 { AM = 0 }
            PM += 1
            if PM == 12 { PM = 0 }
            minute += 1
            if minute == 60 { minute = 0}
        }
        .animation(.bouncy(duration: 0.5, extraBounce: 0.5), value: angle)
        .animation(.bouncy(duration: 0.5, extraBounce: 0.5), value: angut)
    }
}


