import SwiftUI

@main
struct ödevsel: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
