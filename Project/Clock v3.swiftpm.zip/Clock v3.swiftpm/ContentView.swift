//Zeynep Bade Başlıgil - 4.9.25 - AP CSP - Clock
import SwiftUI

enum BearPose {
    case sleeping
    case waking  
    case active
    case tired
}

struct ContentView: View {
    @State private var angle: Double = 0
    @State private var angut: Double = 0
    @State private var tapCount: Int = 0
    @State var hour: Int = 0
    @State var AM: Int = 0
    @State var PM: Int = 0
    @State var minute: Int = 0
    
    var isNight: Bool {
        let mod = tapCount % 24
        return mod < 12
    }
    
    var currentPose: BearPose {
        switch hour {
        case 20...23, 0...6:
            return .sleeping
        case 7...8:
            return .waking
        case 9...17:
            return .active
        case 18...19:
            return .tired
        default:
            return .active
        }
    }
    
    var body: some View {
        let Sedat = isNight ? Color.yellow : Color.indigo.opacity(0.8)
        let Yalcin = isNight ? Text("AM") : Text("PM")
        
        ZStack {
            Sedat
                .ignoresSafeArea()
            
            Yalcin
                .offset(y:280)
                .font(.title)
                .bold()
                .hidden()
            
            Text("Hour: \(hour)")
                .font(.title)
                .foregroundColor(.white)
                .offset(y: -340)
                .bold()
            
            Text("Minute: \(minute)")
                .font(.title)
                .foregroundColor(.white)
                .offset(y: -380)
                .bold()
            
            if Sedat == Color.yellow {
                Text("AM: \(AM)")
                    .font(.title)
                    .foregroundColor(.white)
                    .offset(y: -300)
                    .bold()
            } else {
                Text("PM: \(PM)")
                    .font(.title)
                    .foregroundColor(.white)
                    .offset(y: -220)
                    .bold()
            }
                        Group {
                switch currentPose {
                case .sleeping:
                    SleepingBear()
                case .waking:
                    WakingBear()
                case .active:
                    ActiveBear()
                case .tired:
                    TiredBear()
                }
            }
            .animation(.spring(response: 0.8, dampingFraction: 0.6), value: currentPose)
            

            ZStack {
                Rectangle()
                    .foregroundStyle(.orange)
                    .frame(width: 8, height: 80)
                    .offset(y: -40)
                    .rotationEffect(.degrees(angut))
                
                Rectangle()
                    .foregroundStyle(.white)
                    .frame(width: 8, height: 50)
                    .offset(y: -30)
                    .rotationEffect(.degrees(angle))
            }
            
            Circle()
                .fill(Color.black)
                .frame(width: 12, height: 12)
            
            HStack {
                Button("- Hour") { 
                    hour = hour - 1
                    angle = angle - 15
                } 
                .offset(y:360)
                .foregroundStyle(.white)
                Button("+ Hour") { 
                    hour = hour + 1
                    angle = angle + 15
                }
                .offset(y:360)
                .foregroundStyle(.white)
            }
            HStack {
                Button("- Minute") { 
                    minute = minute - 1
                    angut = angut - 6
                } 
                .offset(y:320)
                .foregroundStyle(.white)
                Button("+ Minute") { 
                    minute = minute + 1
                    angut = angut + 6
                }
                .offset(y:320)
                .foregroundStyle(.white)
            }
        }
        .onTapGesture (count: 2) {
            angle += 15
            angut += 6
            tapCount += 1
            hour += 1
            if hour == 24 { hour = 0 }
            AM += 1
            if AM == 12 { AM = 0 }
            PM += 1
            if PM == 12 { PM = 0 }
            minute += 1
            if minute == 60 { minute = 0}
        }
        .animation(.bouncy(duration: 0.5, extraBounce: 0.5), value: angle)
        .animation(.bouncy(duration: 0.5, extraBounce: 0.5), value: angut)
    }
}

struct SleepingBear: View {
    var body: some View {
        ZStack {
            
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.3, green: 0.2,blue:0.1,alpha:1.0)))
                .frame(width:80, height: 200)
                .offset(x:-50,y:-200)
                .rotationEffect(.degrees(-30))
            
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.3, green: 0.2,blue:0.1,alpha:1.0)))
                .frame(width:80, height: 200)
                .offset(x:100,y:-150)
                .rotationEffect(.degrees(30))
            
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.3, green: 0.2,blue:0.1,alpha:1.0)))
                .frame(width:80, height: 200)
                .offset(x:50,y:-260)
                .rotationEffect(.degrees(140))
            
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.3, green: 0.2,blue:0.1,alpha:1.0)))
                .frame(width:80, height: 200)
                .offset(x:80,y:240)
                .rotationEffect(.degrees(60))
            
            Rectangle()
                .fill(Color.brown)
                .cornerRadius(45.0)
                .frame(width:170, height:155)
                .offset(x:50,y:-170)
            
            Capsule()
                .fill(Color.brown)
                .frame(width:70,height: 60)
                .cornerRadius(45.0)
                .offset(x:-20, y:-270)
                .rotationEffect(.degrees(30))
            
            Capsule()
                .fill(Color.brown)
                .frame(width:70,height: 60)
                .cornerRadius(45.0)
                .offset(x:-170, y:170)
                .rotationEffect(.degrees(130))
            
            Capsule()
                .fill(Color.brown)
                .frame(width:325, height:355)
                .offset(y:30)
            
            Circle()
                .fill(Color.black)
                .frame(width: 200, height: 200)
            
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.9, green: 0.5,blue:0.4,alpha:1.0)))
                .frame(width:40, height:30)
                .offset(x:-20, y:-270)
                .rotationEffect(.degrees(30))
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.9, green: 0.5,blue:0.4,alpha:1.0)))
                .frame(width:40, height:30)
                .offset(x:-170, y:170)
                .rotationEffect(.degrees(130))
            

            Capsule()
                .fill(Color.black)
                .frame(width:30, height:3)
                .offset(x:100,y:-180)
            Capsule()
                .fill(Color.black)
                .frame(width:30, height:3)
                .offset(x:40,y:-180)
            
            Image(systemName: "triangle.fill")
                .resizable()
                .foregroundStyle(.black)
                .frame(width:25, height:20)
                .offset(x:70,y:-150)
            
            Circle()
                .foregroundStyle(Color(CGColor(red:0.3, green: 0.2,blue:0.1,alpha:1.0)))
                .frame(width:50)
                .offset(x:-30,y:130)
            
            Text("Z")
                .foregroundStyle(.white)
                .offset(x:170,y:-210)
                .font(.largeTitle)
                .bold()
            
            Text("Z")
                .foregroundStyle(.white)
                .offset(x:200,y:-260)
                .font(.largeTitle)
                .bold()
            
            Text("Z")
                .foregroundStyle(.white)
                .offset(x:180,y:-310)
                .font(.largeTitle)
                .bold()
        }
    }
}

struct WakingBear: View {
    var body: some View {
        ZStack {
            
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.3, green: 0.2,blue:0.1,alpha:1.0)))
                .frame(width:80, height: 200)
                .offset(x:-60,y:200)
            
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.3, green: 0.2,blue:0.1,alpha:1.0)))
                .frame(width:80, height: 200)
                .offset(x:60,y:200)
            
            Rectangle()
                .fill(Color.brown)
                .cornerRadius(45.0)
                .frame(width:170, height:155)
                .offset(y:-170)
            
            Capsule()
                .fill(Color.brown)
                .frame(width:70,height: 60)
                .cornerRadius(45.0)
                .offset(x:-50, y:-240)
                .rotationEffect(.degrees(30))
            
            Capsule()
                .fill(Color.brown)
                .frame(width:70,height: 60)
                .cornerRadius(45.0)
                .offset(x:-130, y:210)
                .rotationEffect(.degrees(130))
            
            Capsule()
                .fill(Color.brown)
                .frame(width:325, height:355)
                .offset(y:30)
            
            Circle()
                .fill(Color.black)
                .frame(width: 200, height: 200)
            
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.9, green: 0.5,blue:0.4,alpha:1.0)))
                .frame(width:40, height:30)
                .offset(x:-50, y:-240)
                .rotationEffect(.degrees(30))
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.9, green: 0.5,blue:0.4,alpha:1.0)))
                .frame(width:40, height:30)
                .offset(x:-130, y:210)
                .rotationEffect(.degrees(130))

            Capsule()
                .fill(Color.black)
                .frame(width:15, height:10)
                .offset(x:50,y:-185)
            Capsule()
                .fill(Color.black)
                .frame(width:15, height:10)
                .offset(x:-50,y:-185)
            
            Image(systemName: "triangle.fill")
                .resizable()
                .foregroundStyle(.black)
                .frame(width:25, height:20)
                .offset(y:-150)
            
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.3, green: 0.2,blue:0.1,alpha:1.0)))
                .frame(width:80, height: 200)
                .offset(x:-150,y:50)
                .rotationEffect(.degrees(15))
            
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.3, green: 0.2,blue:0.1,alpha:1.0)))
                .frame(width:80, height: 200)
                .offset(x:-150,y:-50)
                .rotationEffect(.degrees(165))
        }
    }
}

struct ActiveBear: View {
    var body: some View {
        ZStack {
            
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.3, green: 0.2,blue:0.1,alpha:1.0)))
                .frame(width:80, height: 200)
                .offset(x:-60,y:200)
            
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.3, green: 0.2,blue:0.1,alpha:1.0)))
                .frame(width:80, height: 200)
                .offset(x:60,y:200)
            
            Rectangle()
                .fill(Color.brown)
                .cornerRadius(45.0)
                .frame(width:170, height:155)
                .offset(y:-170)
            
            Capsule()
                .fill(Color.brown)
                .frame(width:70,height: 60)
                .cornerRadius(45.0)
                .offset(x:-50, y:-240)
                .rotationEffect(.degrees(30))
            
            Capsule()
                .fill(Color.brown)
                .frame(width:70,height: 60)
                .cornerRadius(45.0)
                .offset(x:-130, y:210)
                .rotationEffect(.degrees(130))
            
            Capsule()
                .fill(Color.brown)
                .frame(width:325, height:355)
                .offset(y:30)
            
            Circle()
                .fill(Color.black)
                .frame(width: 200, height: 200)
            
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.9, green: 0.5,blue:0.4,alpha:1.0)))
                .frame(width:40, height:30)
                .offset(x:-50, y:-240)
                .rotationEffect(.degrees(30))
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.9, green: 0.5,blue:0.4,alpha:1.0)))
                .frame(width:40, height:30)
                .offset(x:-130, y:210)
                .rotationEffect(.degrees(130))
            
            Circle()
                .fill(Color.black)
                .frame(width:25, height:25)
                .offset(x:50,y:-180)
            Circle()
                .fill(Color.black)
                .frame(width:25, height:25)
                .offset(x:-50,y:-180)
            
            Image(systemName: "triangle.fill")
                .resizable()
                .foregroundStyle(.black)
                .frame(width:25, height:20)
                .offset(y:-150)
            
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.3, green: 0.2,blue:0.1,alpha:1.0)))
                .frame(width:80, height: 200)
                .offset(x:-120,y:-150)
                .rotationEffect(.degrees(-25))
            
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.3, green: 0.2,blue:0.1,alpha:1.0)))
                .frame(width:80, height: 200)
                .offset(x:-120,y:150)
                .rotationEffect(.degrees(-155))
        }
    }
}

struct TiredBear: View {
    var body: some View {
        ZStack {
            
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.3, green: 0.2,blue:0.1,alpha:1.0)))
                .frame(width:80, height: 200)
                .offset(x:-60,y:200)
            
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.3, green: 0.2,blue:0.1,alpha:1.0)))
                .frame(width:80, height: 200)
                .offset(x:60,y:200)
            
            Rectangle()
                .fill(Color.brown)
                .cornerRadius(45.0)
                .frame(width:170, height:155)
                .offset(y:-170)
            
            Capsule()
                .fill(Color.brown)
                .frame(width:70,height: 60)
                .cornerRadius(45.0)
                .offset(x:-50, y:-240)
                .rotationEffect(.degrees(30))
            
            Capsule()
                .fill(Color.brown)
                .frame(width:70,height: 60)
                .cornerRadius(45.0)
                .offset(x:-130, y:210)
                .rotationEffect(.degrees(130))
            
            Capsule()
                .fill(Color.brown)
                .frame(width:325, height:355)
                .offset(y:30)
            
            Circle()
                .fill(Color.black)
                .frame(width: 200, height: 200)
            
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.9, green: 0.5,blue:0.4,alpha:1.0)))
                .frame(width:40, height:30)
                .offset(x:-50, y:-240)
                .rotationEffect(.degrees(30))
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.9, green: 0.5,blue:0.4,alpha:1.0)))
                .frame(width:40, height:30)
                .offset(x:-130, y:210)
                .rotationEffect(.degrees(130))
            

            Circle()
                .fill(Color.black)
                .frame(width:20, height:20)
                .offset(x:50,y:-170)
            Circle()
                .fill(Color.black)
                .frame(width:20, height:20)
                .offset(x:-50,y:-170)
            
            Image(systemName: "triangle.fill")
                .resizable()
                .foregroundStyle(.black)
                .frame(width:25, height:20)
                .offset(y:-150)
            
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.3, green: 0.2,blue:0.1,alpha:1.0)))
                .frame(width:80, height: 200)
                .offset(x:140,y:40)
                .rotationEffect(.degrees(-160))
            
            Capsule()
                .foregroundStyle(Color(CGColor(red:0.3, green: 0.2,blue:0.1,alpha:1.0)))
                .frame(width:80, height: 200)
                .offset(x:-140,y:40)
                .rotationEffect(.degrees(160))
        }
    }
}
